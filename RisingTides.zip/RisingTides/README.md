# Rising Tides
*A 2D endless runner for urban flood resilience & civic responsibility — SDG 11 & SDG 13*

Built for the "SDG-Aligned 2D Game Development" project brief. Godot **4.2+**, GDScript, GL Compatibility renderer (runs on low-end machines).

## Opening the project
1. Install Godot 4.2 or newer (godotengine.org).
2. Godot Project Manager → **Import** → select the `project.godot` file in this folder.
3. Press **F5** (or the Play button) to run. The main scene is `scenes/StartScreen.tscn`.

## Controls
| Action | Key |
|---|---|
| Jump | `Up Arrow` or `Space` |
| Slide | `Down Arrow` |
| Use character ability | `E` |
| Pause | `Esc` |

## Screen flow
`StartScreen` → `CharacterSelect` → `LevelSelect` → `Game` (with `PauseMenu`, `CivicChoice`, and `GameOverScreen` as overlays) → back to `StartScreen` or retry.

## Project structure
```
RisingTides/
  project.godot          Engine config + input map (jump/slide/ability/pause)
  icon.png               App icon
  autoload/Global.gd     Singleton: character/level data, run results, save file
  scenes/                One .tscn per screen or gameplay entity
  scripts/               One .gd per scene (same file name)
  assets/images/         Backgrounds, waste + obstacle icons (generated placeholders)
  assets/characters/     4 run-cycle spritesheets (10 frames, 128x128 each)
```

## Design notes / how the SDG themes map to mechanics
- **Flood meter (0-100):** rises constantly (SDG 13 — climate pressure never stops). Reaching 100 ends the run.
- **Waste collection & segregation:** the HUD shows a rotating "needed" waste type. Matching it drains the flood meter more and scores more than a random pickup — modeling *why* proper segregation matters, not just "collect items."
- **Hitting an obstacle** (blocked drains, barriers) doesn't insta-kill; it spikes the flood meter, reflecting the brief's "poor choices make later sections harder" rather than a hard fail state.
- **Civic checkpoints** pause the action for a real choice: fund drainage infrastructure (big flood relief + permanently slows future flood growth) vs. ignore it (small penalty, no long-term gain) — modeling good governance's compounding effect.
- **4 characters** mirror the brief's "different community member, different ability" concept and can be re-skinned to represent your 4 team members without touching any code — just swap the PNG each character's data entry points to in `Global.gd`.
- **Level Select** offers 3 fixed-length difficulty tiers plus an Endless mode with a live difficulty ramp, satisfying "levels-to-endless" from the overview.

## Known rough edges (please check first in the editor)
This project was authored directly as text (`.tscn`/`.gd` files) without access to a Godot editor/runtime to click-test it, so before you present it:
- **Sprite/hitbox alignment:** the run-cycle sprites were adapted from a generic template; the player's collision box size (`Player.tscn`) and the ground baseline Y (`Game.tscn`, `WorldLayer/Player` position) are close estimates. Open `Game.tscn`, hit play, and nudge these if the character looks like it's floating or sinking into the road.
- **Difficulty tuning:** flood rates, spawn intervals, and scoring values in `Global.gd` / `Game.gd` are reasonable starting numbers, not playtested — expect to tune them.
- **Art is placeholder-quality:** backgrounds/icons are simple programmer-art generated to match the palette, meant as a functional stand-in. Swapping in real illustrated/pixel art (via the same file names in `assets/`) will not require any script changes.
- **Godot version:** written against 4.2 syntax (`Area2D`, typed GDScript, `process_mode`). If you're on Godot 3.x, it will not open — you'd need Godot 4.

## Extending it further
- Add more obstacle/waste variety by adding entries to the `TEXTURES` dicts in `Obstacle.gd` / `Waste.gd`.
- Add more civic checkpoint scenarios by giving `CivicChoice.gd` a list of prompts instead of one fixed prompt.
- Add persistent character unlocks or a shop using the same `Global.SAVE_PATH` JSON file, extending the `save_game()`/`load_save()` functions.
