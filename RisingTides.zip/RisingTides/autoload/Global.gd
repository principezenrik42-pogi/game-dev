extends Node
## Global game state shared across all scenes: selected character, selected
## level, running score, and persistent best-score save data.

signal high_score_updated(new_high_score: int)

# ---------------------------------------------------------------------------
# Character data
# ---------------------------------------------------------------------------
# Each character mirrors the "playable characters" table from the design doc.
var characters := [
	{
		"id": "runner",
		"name": "The Runner",
		"ability_name": "Quick Dash",
		"description": "Dashes forward with a burst of speed, dodging obstacles and briefly ignoring collisions.",
		"sprite": "res://assets/characters/runner_run.png",
		"color": Color(0.75, 0.2, 0.2),
	},
	{
		"id": "collector",
		"name": "The Collector",
		"ability_name": "Magnetic Grab",
		"description": "Pulls in every scrap of nearby waste for a few seconds, boosting collection.",
		"sprite": "res://assets/characters/collector_run.png",
		"color": Color(0.25, 0.55, 0.3),
	},
	{
		"id": "builder",
		"name": "The Builder",
		"ability_name": "Barrier Deploy",
		"description": "Drops a temporary barrier that blocks one hit or clears a blocked drain.",
		"sprite": "res://assets/characters/builder_run.png",
		"color": Color(0.9, 0.55, 0.15),
	},
	{
		"id": "advocate",
		"name": "The Advocate",
		"ability_name": "Civic Influence",
		"description": "Guarantees the best outcome at the next civic checkpoint and calms the flood.",
		"sprite": "res://assets/characters/advocate_run.png",
		"color": Color(0.2, 0.3, 0.55),
	},
]

# ---------------------------------------------------------------------------
# Level data
# ---------------------------------------------------------------------------
var levels := [
	{"id": 0, "name": "Level 1 - Barangay Streets", "scroll_speed": 220.0, "flood_rate": 3.0, "spawn_interval": 1.4, "endless": false, "duration": 60.0},
	{"id": 1, "name": "Level 2 - City Avenue", "scroll_speed": 260.0, "flood_rate": 4.0, "spawn_interval": 1.15, "endless": false, "duration": 75.0},
	{"id": 2, "name": "Level 3 - Downtown Monsoon", "scroll_speed": 300.0, "flood_rate": 5.0, "spawn_interval": 0.95, "endless": false, "duration": 90.0},
	{"id": 3, "name": "Endless - Rising Tides", "scroll_speed": 220.0, "flood_rate": 3.2, "spawn_interval": 1.3, "endless": true, "duration": -1.0},
]

var selected_character_index: int = 0
var selected_level_index: int = 0

# Set true by the Advocate's "Civic Influence" ability; consumed by the next
# civic checkpoint to auto-apply the best outcome.
var advocate_guarantee: bool = false

# ---------------------------------------------------------------------------
# Run/session results (read by the Game Over screen)
# ---------------------------------------------------------------------------
var last_score: int = 0
var last_waste_collected: int = 0
var last_distance: int = 0
var high_score: int = 0

const SAVE_PATH := "user://rising_tides_save.json"

func _ready() -> void:
	load_save()

func get_selected_character() -> Dictionary:
	return characters[selected_character_index]

func get_selected_level() -> Dictionary:
	return levels[selected_level_index]

func report_run_result(score: int, waste_collected: int, distance: int) -> void:
	last_score = score
	last_waste_collected = waste_collected
	last_distance = distance
	if score > high_score:
		high_score = score
		high_score_updated.emit(high_score)
	save_game()

func save_game() -> void:
	var data := {"high_score": high_score}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))
		f.close()

func load_save() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f:
		var text := f.get_as_text()
		f.close()
		var parsed = JSON.parse_string(text)
		if typeof(parsed) == TYPE_DICTIONARY and parsed.has("high_score"):
			high_score = int(parsed["high_score"])
