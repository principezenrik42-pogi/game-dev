extends TextureRect
## Attach to a TextureRect that uses assets/shaders/scroll.gdshader and has
## stretch_mode = Tile + texture_repeat = Enabled. Game.gd sets `scroll_speed`
## every frame (usually a fraction of the world scroll speed for parallax);
## this node accumulates that into a shader offset so the background visibly
## advances instead of sitting still.

@export var scroll_speed: float = 0.0

var _offset: float = 0.0

func _process(delta: float) -> void:
	if scroll_speed == 0.0 or material == null:
		return
	# Wrap the accumulator so it never grows unbounded over a long run.
	_offset = fmod(_offset + scroll_speed * delta, 100000.0)
	material.set_shader_parameter("offset_x", _offset)
