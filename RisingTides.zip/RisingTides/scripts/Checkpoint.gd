extends Area2D

@onready var sprite: Sprite2D = $Sprite2D
@onready var collision: CollisionShape2D = $CollisionShape2D

var speed: float = 220.0
var triggered: bool = false
## "civic" opens the CivicChoice dialogue; "minigame" opens the sandbag
## mini-game instead. Game.gd picks one at spawn time so the two checkpoint
## types alternate rather than the player only ever seeing one of them.
var mode: String = "civic"

func setup(p_speed: float, p_mode: String = "civic") -> void:
	speed = p_speed
	mode = p_mode
	sprite.texture = load("res://assets/images/icon_checkpoint.png")
	# Tall hitbox so the checkpoint triggers whether the player is jumping,
	# sliding, or running normally -- civic checkpoints aren't meant to be dodged.
	var shape := RectangleShape2D.new()
	shape.size = Vector2(30, 300)
	collision.shape = shape

func _process(delta: float) -> void:
	position.x -= speed * delta
	if position.x < -80:
		queue_free()
