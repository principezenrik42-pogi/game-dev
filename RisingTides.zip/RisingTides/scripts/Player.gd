extends Area2D
## Controls vertical movement (jump / slide), running animation, and the
## per-character special ability. Horizontal position stays fixed; the world
## scrolls past the player, which is the classic endless-runner setup.

signal ability_state_changed(cooldown_ratio: float, ready: bool)
signal hit_obstacle
signal collected_waste(waste_type: String)
signal entered_checkpoint(checkpoint: Node)

const GRAVITY := 2200.0
const JUMP_VELOCITY := -760.0
const GROUND_TOLERANCE := 2.0
const ABILITY_COOLDOWN := 7.0

@onready var sprite: Sprite2D = $Sprite2D
@onready var collision: CollisionShape2D = $CollisionShape2D
@onready var shield_fx: ColorRect = $ShieldFx

var ground_y: float = 0.0
var velocity_y: float = 0.0
var is_sliding: bool = false
var normal_shape_size: Vector2
var frame_counter: int = 0

var ability_cooldown_timer: float = 0.0
var character_id: String = "runner"

# Ability state
var invulnerable: bool = false
var invuln_timer: float = 0.0
var shielded: bool = false
var magnet_active: bool = false
var magnet_timer: float = 0.0
var magnet_radius: float = 26.0

func _ready() -> void:
	ground_y = position.y
	var data: Dictionary = Global.get_selected_character()
	character_id = data["id"]
	sprite.texture = load(data["sprite"])
	normal_shape_size = collision.shape.size

func _physics_process(delta: float) -> void:
	_handle_jump_slide()
	_apply_gravity(delta)
	_update_ability_timers(delta)

func _handle_jump_slide() -> void:
	var on_ground := position.y >= ground_y - GROUND_TOLERANCE
	if Input.is_action_just_pressed("jump") and on_ground and not is_sliding:
		velocity_y = JUMP_VELOCITY
	if Input.is_action_pressed("slide") and on_ground:
		_start_slide()
	elif is_sliding and not Input.is_action_pressed("slide"):
		_end_slide()
	if Input.is_action_just_pressed("ability") and ability_cooldown_timer <= 0.0:
		_trigger_ability()

func _apply_gravity(delta: float) -> void:
	if position.y < ground_y - GROUND_TOLERANCE or velocity_y < 0.0:
		velocity_y += GRAVITY * delta
		position.y += velocity_y * delta
		if position.y >= ground_y:
			position.y = ground_y
			velocity_y = 0.0

func _start_slide() -> void:
	if is_sliding:
		return
	is_sliding = true
	collision.shape.size = Vector2(normal_shape_size.x, normal_shape_size.y * 0.5)
	sprite.scale.y = 1.3
	sprite.position.y = 14

func _end_slide() -> void:
	is_sliding = false
	collision.shape.size = normal_shape_size
	sprite.scale.y = 2.6
	sprite.position.y = 0

func _on_anim_timer_timeout() -> void:
	var on_ground := position.y >= ground_y - GROUND_TOLERANCE
	if not on_ground:
		sprite.frame = 3
		return
	if is_sliding:
		sprite.frame = 0
		return
	frame_counter = (frame_counter + 1) % 10
	sprite.frame = frame_counter

# ---------------------------------------------------------------------------
# Abilities
# ---------------------------------------------------------------------------
func _trigger_ability() -> void:
	ability_cooldown_timer = ABILITY_COOLDOWN
	match character_id:
		"runner":
			invulnerable = true
			invuln_timer = 0.8
			modulate = Color(1, 1, 1, 0.6)
		"collector":
			magnet_active = true
			magnet_timer = 4.0
			magnet_radius = 130.0
		"builder":
			shielded = true
			shield_fx.visible = true
		"advocate":
			Global.advocate_guarantee = true
	ability_state_changed.emit(1.0, false)

# Called by Game.gd when the sandbag mini-game is won: a short window of
# invulnerability, visually distinct (golden tint) from the Runner's own
# Quick Dash ability so the reward reads as "earned", not "the same skill".
func grant_powerup(duration: float) -> void:
	invulnerable = true
	invuln_timer = max(invuln_timer, duration)
	modulate = Color(1.0, 0.9, 0.35, 0.85)

func _update_ability_timers(delta: float) -> void:
	if ability_cooldown_timer > 0.0:
		ability_cooldown_timer = max(0.0, ability_cooldown_timer - delta)
		ability_state_changed.emit(1.0 - (ability_cooldown_timer / ABILITY_COOLDOWN), ability_cooldown_timer <= 0.0)
	if invulnerable:
		invuln_timer -= delta
		if invuln_timer <= 0.0:
			invulnerable = false
			modulate = Color(1, 1, 1, 1)
	if magnet_active:
		magnet_timer -= delta
		if magnet_timer <= 0.0:
			magnet_active = false
			magnet_radius = 26.0

func _on_area_entered(area: Node2D) -> void:
	if area.is_in_group("obstacle"):
		if invulnerable:
			return
		if shielded:
			shielded = false
			shield_fx.visible = false
			area.queue_free()
			return
		hit_obstacle.emit()
	elif area.is_in_group("waste"):
		collected_waste.emit(area.waste_type)
		area.queue_free()
	elif area.is_in_group("checkpoint"):
		entered_checkpoint.emit(area)
