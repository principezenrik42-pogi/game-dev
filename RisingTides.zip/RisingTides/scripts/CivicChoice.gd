extends Control

signal choice_made(flood_delta: float, rate_multiplier: float, bonus_score: int)

func open() -> void:
	visible = true

func _on_option_a_pressed() -> void:
	visible = false
	# Good governance choice: lowers flood level now and slows future flood growth.
	choice_made.emit(-20.0, 0.93, 150)

func _on_option_b_pressed() -> void:
	visible = false
	# Inaction: small immediate penalty, no long-term benefit.
	choice_made.emit(6.0, 1.0, 0)

func auto_best_choice() -> void:
	visible = false
	choice_made.emit(-30.0, 0.9, 150)
