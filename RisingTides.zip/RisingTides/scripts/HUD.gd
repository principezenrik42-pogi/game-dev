extends Control

signal pause_requested

@onready var score_label: Label = $ScoreLabel
@onready var waste_label: Label = $WasteLabel
@onready var needed_icon: TextureRect = $NeededIcon
@onready var needed_label: Label = $NeededLabel
@onready var flood_fill: ColorRect = $FloodMeterFill
@onready var flood_bg: ColorRect = $FloodMeterBg
@onready var phase_label: Label = $PhaseLabel
@onready var ability_label: Label = $AbilityLabel
@onready var ability_fill: ColorRect = $AbilityBarFill
@onready var ability_bg: ColorRect = $AbilityBarBg

const WASTE_ICONS := {
	"bio": "res://assets/images/icon_waste_bio.png",
	"recycle": "res://assets/images/icon_waste_recycle.png",
	"residual": "res://assets/images/icon_waste_residual.png",
}
const WASTE_NAMES := {
	"bio": "Biodegradable",
	"recycle": "Recyclable",
	"residual": "Residual",
}

func set_score(value: int) -> void:
	score_label.text = "Score: %d" % value

func set_waste(value: int) -> void:
	waste_label.text = "Waste collected: %d" % value

func set_needed_type(waste_type: String) -> void:
	needed_icon.texture = load(WASTE_ICONS.get(waste_type, WASTE_ICONS["bio"]))
	needed_label.text = "Needed: %s" % WASTE_NAMES.get(waste_type, "Any")

func set_flood(ratio: float) -> void:
	ratio = clamp(ratio, 0.0, 1.0)
	var full_width: float = flood_bg.size.x - 4.0
	flood_fill.size.x = full_width * ratio
	if ratio > 0.75:
		flood_fill.color = Color(0.85, 0.2, 0.2)
	elif ratio > 0.45:
		flood_fill.color = Color(0.95, 0.65, 0.2)
	else:
		flood_fill.color = Color(0.25, 0.55, 0.9)

func set_phase(phase_name: String) -> void:
	phase_label.text = phase_name.to_upper()
	match phase_name:
		"Rising":
			phase_label.modulate = Color(1.0, 0.75, 0.3)
		"Catastrophic":
			phase_label.modulate = Color(1.0, 0.35, 0.35)
		_:
			phase_label.modulate = Color(0.6, 0.85, 1.0)

func set_ability(ratio: float, ready: bool) -> void:
	var full_width: float = ability_bg.size.x - 4.0
	ability_fill.size.x = full_width * clamp(ratio, 0.0, 1.0)
	ability_label.text = "Ability: Ready [E]" if ready else "Ability: Charging..."

func _on_pause_pressed() -> void:
	pause_requested.emit()
