extends Area2D

@onready var sprite: Sprite2D = $Sprite2D
@onready var collision: CollisionShape2D = $CollisionShape2D

var speed: float = 220.0
var waste_type: String = "bio"

const TEXTURES := {
	"bio": "res://assets/images/icon_waste_bio.png",
	"recycle": "res://assets/images/icon_waste_recycle.png",
	"residual": "res://assets/images/icon_waste_residual.png",
}

func setup(p_type: String, p_speed: float) -> void:
	waste_type = p_type
	speed = p_speed
	sprite.texture = load(TEXTURES.get(waste_type, TEXTURES["bio"]))
	var shape := CircleShape2D.new()
	shape.radius = 16.0
	collision.shape = shape

func _process(delta: float) -> void:
	var player := get_tree().get_first_node_in_group("player")
	if player and player.magnet_active:
		var dist := global_position.distance_to(player.global_position)
		if dist < player.magnet_radius:
			global_position = global_position.move_toward(player.global_position, 420.0 * delta)
	position.x -= speed * delta
	if position.x < -80:
		queue_free()
