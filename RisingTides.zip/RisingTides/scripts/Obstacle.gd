extends Area2D
## Three hazard kinds, each with its own required dodge so obstacles finally
## "make sense" instead of being the same spike reused floor/ceiling:
##   trash      - low pile on the ground, easiest to clear -- jump over it.
##   driftwood  - a taller plank with nails, still ground-based -- jump over it,
##                but it demands a slightly fuller jump than trash does.
##   wire       - a sagging live wire at head height -- slide under it, or
##                clear it with a full jump.
## Collision sizes below are tuned against the player's hitbox (44x78 / 44x39
## while sliding, see Player.tscn) so every kind has a real, learnable window
## instead of needing pixel-perfect timing.

@onready var sprite: Sprite2D = $Sprite2D
@onready var collision: CollisionShape2D = $CollisionShape2D

var speed: float = 220.0
var kind: String = "trash"

const TEXTURES := {
	"trash": "res://assets/images/icon_hazard_trash.png",
	"driftwood": "res://assets/images/icon_hazard_driftwood.png",
	"wire": "res://assets/images/icon_hazard_wire.png",
}

func setup(p_kind: String, p_speed: float) -> void:
	kind = p_kind
	speed = p_speed
	sprite.texture = load(TEXTURES.get(kind, TEXTURES["trash"]))
	sprite.rotation_degrees = 0
	var shape := RectangleShape2D.new()
	match kind:
		"trash":
			shape.size = Vector2(36, 26)
			sprite.scale = Vector2(1.1, 1.1)
		"driftwood":
			shape.size = Vector2(26, 46)
			sprite.scale = Vector2(1.1, 1.3)
		"wire":
			shape.size = Vector2(56, 26)
			position.y -= 36
			sprite.scale = Vector2(1.3, 1.1)
		_:
			shape.size = Vector2(36, 26)
	collision.shape = shape

func _process(delta: float) -> void:
	position.x -= speed * delta
	if position.x < -80:
		queue_free()
