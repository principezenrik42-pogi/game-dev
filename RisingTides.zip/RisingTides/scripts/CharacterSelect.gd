extends Control

@onready var char_sprite: Sprite2D = $SpriteHolder/CharSprite
@onready var name_label: Label = $Panel/InfoBox/NameLabel
@onready var ability_label: Label = $Panel/InfoBox/AbilityLabel
@onready var desc_label: Label = $Panel/InfoBox/DescLabel
@onready var dots: HBoxContainer = $Dots

var index: int = 0
var dot_nodes: Array[ColorRect] = []

func _ready() -> void:
	index = Global.selected_character_index
	for i in Global.characters.size():
		var dot := ColorRect.new()
		dot.custom_minimum_size = Vector2(10, 10)
		dots.add_child(dot)
		dot_nodes.append(dot)
	_refresh()

func _refresh() -> void:
	var data: Dictionary = Global.characters[index]
	char_sprite.texture = load(data["sprite"])
	name_label.text = data["name"]
	ability_label.text = "Ability: %s" % data["ability_name"]
	desc_label.text = data["description"]
	for i in dot_nodes.size():
		dot_nodes[i].color = Color(1, 1, 1, 1) if i == index else Color(1, 1, 1, 0.3)

func _on_left_pressed() -> void:
	index = (index - 1 + Global.characters.size()) % Global.characters.size()
	_refresh()

func _on_right_pressed() -> void:
	index = (index + 1) % Global.characters.size()
	_refresh()

func _on_anim_timeout() -> void:
	char_sprite.frame = (char_sprite.frame + 1) % 10

func _on_back_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/StartScreen.tscn")

func _on_confirm_pressed() -> void:
	Global.selected_character_index = index
	get_tree().change_scene_to_file("res://scenes/LevelSelect.tscn")
