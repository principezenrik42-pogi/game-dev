extends Control

@onready var title: Label = $Panel/VBox/Title
@onready var score_label: Label = $Panel/VBox/ScoreLabel
@onready var waste_label: Label = $Panel/VBox/WasteLabel
@onready var best_label: Label = $Panel/VBox/BestLabel

func show_results(score: int, waste: int, won: bool) -> void:
	title.text = "YOU REACHED SAFETY!" if won else "THE FLOOD CAUGHT YOU"
	score_label.text = "Score: %d" % score
	waste_label.text = "Waste collected: %d" % waste
	best_label.text = "Best: %d" % Global.high_score
	visible = true
	get_tree().paused = true

func _on_retry_pressed() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_menu_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/StartScreen.tscn")
