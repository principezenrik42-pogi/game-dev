extends Control
## "Sandbag Rush" -- the mini-game alternative to a civic-choice dialogue.
## Mash the jump key before the timer runs out to seal the wall. This is the
## "cause and effect" checkpoint variant: succeed and you get a flood cut,
## bonus score, and a temporary power-up; fail and the flood gets worse, same
## as ignoring a civic checkpoint does.

signal completed(success: bool)

const TAPS_NEEDED := 6
const TIME_LIMIT := 3.5

@onready var prompt_label: Label = $Panel/VBox/PromptLabel
@onready var progress_bar: ProgressBar = $Panel/VBox/ProgressBar
@onready var timer_label: Label = $Panel/VBox/TimerLabel

var taps: int = 0
var time_left: float = 0.0
var active: bool = false

func _ready() -> void:
	visible = false

func open() -> void:
	visible = true
	active = true
	taps = 0
	time_left = TIME_LIMIT
	progress_bar.max_value = TAPS_NEEDED
	progress_bar.value = 0
	prompt_label.text = "Flood surge! Mash JUMP to stack the sandbags!"
	timer_label.text = "%.1fs" % TIME_LIMIT

func _process(delta: float) -> void:
	if not active:
		return
	time_left -= delta
	timer_label.text = "%.1fs" % max(time_left, 0.0)
	if time_left <= 0.0:
		_finish(false)
		return
	if Input.is_action_just_pressed("jump"):
		taps += 1
		progress_bar.value = taps
		if taps >= TAPS_NEEDED:
			_finish(true)

func _finish(success: bool) -> void:
	active = false
	visible = false
	completed.emit(success)
