extends Control
## Core gameplay loop: scrolling difficulty, spawning obstacles/waste/civic
## checkpoints, tracking the flood meter, and routing to the pause / game
## over screens.
##
## Difficulty is driven by three flood PHASES (calm -> rising -> catastrophic)
## keyed off the current flood level, not just elapsed time, so "the flood
## slowly rises, then it gets faster and worse" is literally what happens:
## scroll speed, flood speed, obstacle frequency and score all step up
## together as the meter climbs, and ease back down if the player buys the
## flood back down with waste pickups or a checkpoint.

const ObstacleScene := preload("res://scenes/Obstacle.tscn")
const WasteScene := preload("res://scenes/Waste.tscn")
const CheckpointScene := preload("res://scenes/Checkpoint.tscn")
const CivicChoiceScene := preload("res://scenes/CivicChoice.tscn")
const MiniGameScene := preload("res://scenes/MiniGame.tscn")

@onready var player: Area2D = $WorldLayer/Player
@onready var hud = $HUD
@onready var pause_menu = $PauseMenu
@onready var game_over_screen = $GameOverScreen
@onready var flood_water: TextureRect = $FloodWater
@onready var spawn_timer: Timer = $SpawnTimer
@onready var road: TextureRect = $Road
@onready var buildings: TextureRect = $Buildings

var civic_choice: Control
var minigame: Control

enum Phase { CALM, RISING, CATASTROPHIC }
var phase: int = Phase.CALM

# Multipliers applied on top of the level's base numbers as the flood phase
# escalates. Calm = the level's original pace; Catastrophic is meaningfully
# harder (faster scroll/flood, more obstacles) but pays out more score.
const PHASE_SCROLL_MULT := {Phase.CALM: 1.0, Phase.RISING: 1.25, Phase.CATASTROPHIC: 1.55}
const PHASE_FLOOD_MULT := {Phase.CALM: 1.0, Phase.RISING: 1.35, Phase.CATASTROPHIC: 1.8}
const PHASE_SPAWN_MULT := {Phase.CALM: 1.0, Phase.RISING: 0.8, Phase.CATASTROPHIC: 0.6}
const PHASE_OBSTACLE_SHARE := {Phase.CALM: 0.3, Phase.RISING: 0.45, Phase.CATASTROPHIC: 0.6}
const PHASE_SCORE_MULT := {Phase.CALM: 1.0, Phase.RISING: 1.3, Phase.CATASTROPHIC: 1.6}
const PHASE_BONUS_RATE := {Phase.CALM: 0.0, Phase.RISING: 2.0, Phase.CATASTROPHIC: 5.0}
const PHASE_NAMES := {Phase.CALM: "Calm", Phase.RISING: "Rising", Phase.CATASTROPHIC: "Catastrophic"}
const RISING_THRESHOLD := 33.0
const CATASTROPHIC_THRESHOLD := 66.0

var base_scroll_speed: float
var base_flood_rate: float
var base_spawn_interval: float
var scroll_speed: float
var flood_rate: float
var endless: bool
var duration: float

var elapsed_time: float = 0.0
var distance: float = 0.0
var score: int = 0
var distance_score_baseline: int = 0
var phase_bonus: float = 0.0
var waste_collected: int = 0
var flood_level: float = 0.0

var frozen: bool = false
var game_over_flag: bool = false
var last_checkpoint_time: float = -999.0
var required_waste_type: String = "bio"

const WASTE_TYPES := ["bio", "recycle", "residual"]

# Bag-based spawn queue: instead of an independent random roll on every
# timer tick (which streaks -- "sometimes it's all obstacles, sometimes
# there's nothing to do"), each refill builds a small shuffled bag with a
# guaranteed ratio of obstacle/waste/checkpoint, so every short stretch of
# play has a fair, readable mix.
var spawn_bag: Array = []
const BAG_SIZE := 10
const BAG_CHECKPOINT_SLOTS := 1

func _ready() -> void:
	var level: Dictionary = Global.get_selected_level()
	base_scroll_speed = level["scroll_speed"]
	base_flood_rate = level["flood_rate"]
	base_spawn_interval = level["spawn_interval"]
	scroll_speed = base_scroll_speed
	flood_rate = base_flood_rate
	endless = level["endless"]
	duration = level["duration"]

	spawn_timer.wait_time = base_spawn_interval
	spawn_timer.timeout.connect(_on_spawn_timer_timeout)

	player.hit_obstacle.connect(_on_player_hit_obstacle)
	player.collected_waste.connect(_on_player_collected_waste)
	player.entered_checkpoint.connect(_on_player_entered_checkpoint)
	player.ability_state_changed.connect(_on_ability_state_changed)

	hud.pause_requested.connect(_toggle_pause)
	hud.set_score(0)
	hud.set_waste(0)
	hud.set_flood(0.0)
	hud.set_phase(PHASE_NAMES[Phase.CALM])

	civic_choice = CivicChoiceScene.instantiate()
	add_child(civic_choice)
	civic_choice.choice_made.connect(_on_civic_choice_made)

	minigame = MiniGameScene.instantiate()
	add_child(minigame)
	minigame.completed.connect(_on_minigame_completed)

	var required_timer := Timer.new()
	required_timer.wait_time = 8.0
	required_timer.autostart = true
	add_child(required_timer)
	required_timer.timeout.connect(_rotate_required_type)
	_rotate_required_type()

	Global.advocate_guarantee = false
	_refill_spawn_bag()

func _process(delta: float) -> void:
	if frozen or game_over_flag:
		return

	elapsed_time += delta
	distance += scroll_speed * delta
	flood_level = clamp(flood_level + flood_rate * delta, 0.0, 100.0)
	_update_phase()

	# Score is now purely additive: distance and phase-danger both add ticks
	# on top of whatever score already exists, instead of the old
	# `score = int(distance / 8.0)` which recalculated score from scratch
	# every frame and silently erased any bonus just earned from a waste
	# pickup or checkpoint the moment the next frame ran.
	var new_distance_score := int(distance / 8.0)
	if new_distance_score > distance_score_baseline:
		score += new_distance_score - distance_score_baseline
		distance_score_baseline = new_distance_score
	phase_bonus += PHASE_BONUS_RATE[phase] * delta
	var bonus_ticks := int(phase_bonus)
	if bonus_ticks > 0:
		score += bonus_ticks
		phase_bonus -= bonus_ticks

	scroll_speed = base_scroll_speed * PHASE_SCROLL_MULT[phase]
	flood_rate = base_flood_rate * PHASE_FLOOD_MULT[phase]
	if endless:
		# Endless mode keeps a slow long-run creep on top of the phase steps,
		# capped so a very long run doesn't spiral into an unplayable blur.
		var creep: float = min(elapsed_time * 0.01, 1.4)
		scroll_speed = min(scroll_speed * (1.0 + creep * 0.3), 560.0)
		flood_rate = min(flood_rate * (1.0 + creep * 0.2), 11.0)

	hud.set_score(score)
	hud.set_flood(flood_level / 100.0)
	flood_water.offset_top = -(40.0 + flood_level * 1.7)

	road.scroll_speed = scroll_speed
	buildings.scroll_speed = scroll_speed * 0.35

	if flood_level >= 100.0:
		_game_over(false)
	elif not endless and elapsed_time >= duration:
		_game_over(true)

	if Input.is_action_just_pressed("pause"):
		_toggle_pause()

func _update_phase() -> void:
	var new_phase := Phase.CALM
	if flood_level >= CATASTROPHIC_THRESHOLD:
		new_phase = Phase.CATASTROPHIC
	elif flood_level >= RISING_THRESHOLD:
		new_phase = Phase.RISING
	if new_phase != phase:
		phase = new_phase
		spawn_timer.wait_time = base_spawn_interval * PHASE_SPAWN_MULT[phase]
		hud.set_phase(PHASE_NAMES[phase])

func _toggle_pause() -> void:
	if game_over_flag:
		return
	if pause_menu.visible:
		pause_menu.close()
	else:
		pause_menu.open()

func _rotate_required_type() -> void:
	required_waste_type = WASTE_TYPES[randi() % WASTE_TYPES.size()]
	hud.set_needed_type(required_waste_type)

# ---------------------------------------------------------------------------
# Spawning
# ---------------------------------------------------------------------------
func _refill_spawn_bag() -> void:
	var obstacle_share: float = PHASE_OBSTACLE_SHARE[phase]
	var obstacle_slots: int = int(round((BAG_SIZE - BAG_CHECKPOINT_SLOTS) * obstacle_share))
	obstacle_slots = clamp(obstacle_slots, 1, BAG_SIZE - BAG_CHECKPOINT_SLOTS - 1)
	var waste_slots: int = BAG_SIZE - BAG_CHECKPOINT_SLOTS - obstacle_slots

	spawn_bag.clear()
	for i in obstacle_slots:
		spawn_bag.append("obstacle")
	for i in waste_slots:
		spawn_bag.append("waste")
	for i in BAG_CHECKPOINT_SLOTS:
		spawn_bag.append("checkpoint")
	spawn_bag.shuffle()
	_break_long_runs()

# Avoid 3+ obstacles landing back to back purely by shuffle chance -- that's
# exactly the "sometimes there's nothing you can do" streak players hit.
func _break_long_runs() -> void:
	var run := 0
	for i in spawn_bag.size():
		if spawn_bag[i] == "obstacle":
			run += 1
			if run >= 3:
				for j in range(i + 1, spawn_bag.size()):
					if spawn_bag[j] != "obstacle":
						var tmp = spawn_bag[i]
						spawn_bag[i] = spawn_bag[j]
						spawn_bag[j] = tmp
						break
				run = 0
		else:
			run = 0

func _on_spawn_timer_timeout() -> void:
	if frozen or game_over_flag:
		return
	if spawn_bag.is_empty():
		_refill_spawn_bag()
	var next: String = spawn_bag.pop_front()
	match next:
		"obstacle":
			_spawn_obstacle()
		"waste":
			_spawn_waste()
		"checkpoint":
			_maybe_spawn_checkpoint()

func _spawn_obstacle() -> void:
	var kinds := ["trash", "driftwood", "wire"]
	var kind: String = kinds[randi() % kinds.size()]
	var obstacle = ObstacleScene.instantiate()
	$WorldLayer.add_child(obstacle)
	obstacle.position = Vector2(700, 251)
	obstacle.setup(kind, scroll_speed)

func _spawn_waste() -> void:
	var waste_type: String
	if randf() < 0.55:
		waste_type = required_waste_type
	else:
		waste_type = WASTE_TYPES[randi() % WASTE_TYPES.size()]
	var waste = WasteScene.instantiate()
	$WorldLayer.add_child(waste)
	var y := 251.0 if randf() < 0.5 else 195.0
	waste.position = Vector2(700, y)
	waste.setup(waste_type, scroll_speed)

func _maybe_spawn_checkpoint() -> void:
	if elapsed_time - last_checkpoint_time < 10.0:
		_spawn_waste()
		return
	last_checkpoint_time = elapsed_time
	var checkpoint = CheckpointScene.instantiate()
	$WorldLayer.add_child(checkpoint)
	checkpoint.position = Vector2(700, 251)
	var mode := "minigame" if randf() < 0.5 else "civic"
	checkpoint.setup(scroll_speed, mode)

# ---------------------------------------------------------------------------
# Signal handlers
# ---------------------------------------------------------------------------
func _on_player_hit_obstacle() -> void:
	flood_level = clamp(flood_level + 15.0, 0.0, 100.0)

func _on_player_collected_waste(waste_type: String) -> void:
	waste_collected += 1
	var mult: float = PHASE_SCORE_MULT[phase]
	if waste_type == required_waste_type:
		score += int(50 * mult)
		flood_level = clamp(flood_level - 8.0, 0.0, 100.0)
	else:
		score += int(10 * mult)
		flood_level = clamp(flood_level - 3.0, 0.0, 100.0)
	hud.set_waste(waste_collected)

func _on_player_entered_checkpoint(checkpoint: Node) -> void:
	if frozen or checkpoint.triggered:
		return
	checkpoint.triggered = true
	frozen = true
	if Global.advocate_guarantee:
		Global.advocate_guarantee = false
		civic_choice.auto_best_choice()
	elif checkpoint.mode == "minigame":
		minigame.open()
	else:
		civic_choice.open()

func _on_civic_choice_made(flood_delta: float, rate_multiplier: float, bonus_score: int) -> void:
	flood_level = clamp(flood_level + flood_delta, 0.0, 100.0)
	base_flood_rate *= rate_multiplier
	score += int(bonus_score * PHASE_SCORE_MULT[phase])
	frozen = false

func _on_minigame_completed(success: bool) -> void:
	if success:
		flood_level = clamp(flood_level - 18.0, 0.0, 100.0)
		score += int(120 * PHASE_SCORE_MULT[phase])
		player.grant_powerup(4.0)
	else:
		flood_level = clamp(flood_level + 12.0, 0.0, 100.0)
	frozen = false

func _on_ability_state_changed(ratio: float, ready: bool) -> void:
	hud.set_ability(ratio, ready)

func _game_over(won: bool) -> void:
	if game_over_flag:
		return
	game_over_flag = true
	Global.report_run_result(score, waste_collected, int(distance))
	game_over_screen.show_results(score, waste_collected, won)
