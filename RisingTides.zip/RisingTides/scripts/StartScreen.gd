extends Control

@onready var how_to_panel: Panel = $HowToPanel
@onready var high_score_label: Label = $HighScoreLabel

func _ready() -> void:
	high_score_label.text = "Best Score: %d" % Global.high_score
	get_tree().paused = false

func _on_play_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/CharacterSelect.tscn")

func _on_how_to_pressed() -> void:
	how_to_panel.visible = true

func _on_how_to_close_pressed() -> void:
	how_to_panel.visible = false

func _on_quit_pressed() -> void:
	get_tree().quit()
