extends Control

@onready var level_list: VBoxContainer = $LevelList

func _ready() -> void:
	for i in Global.levels.size():
		var lvl: Dictionary = Global.levels[i]
		var btn := Button.new()
		btn.custom_minimum_size = Vector2(300, 42)
		btn.text = lvl["name"]
		btn.add_theme_font_size_override("font_size", 15)
		btn.pressed.connect(_on_level_pressed.bind(i))
		level_list.add_child(btn)

func _on_level_pressed(i: int) -> void:
	Global.selected_level_index = i
	get_tree().change_scene_to_file("res://scenes/Game.tscn")

func _on_back_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/CharacterSelect.tscn")
